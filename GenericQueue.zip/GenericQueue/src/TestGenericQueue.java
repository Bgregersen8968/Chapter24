import java.util.ArrayList;
import java.util.List;

class Queue<T> {
    private List<T> items;

    public Queue() {
        this.items = new ArrayList<>();
    }

    public void enqueue(T item) {
        this.items.add(item);
    }

    public T dequeue() {
        if (!isEmpty()) {
            return this.items.remove(0);
        } else {
            return null;
        }
    }

    public boolean isEmpty() {
        return this.items.isEmpty();
    }

    @Override
    public String toString() {
        return this.items.toString();
    }
}

class GenericQueue<T> extends Queue<T> {
    // Inherits from the Queue class
}

public class TestGenericQueue {
    public static void main(String[] args) {
        testGenericQueue();
    }

    public static void testGenericQueue() {
        GenericQueue<Integer> genericQueue = new GenericQueue<>();

        System.out.println("Enqueuing elements:");
        genericQueue.enqueue(1);
        genericQueue.enqueue(2);
        genericQueue.enqueue(3);
        System.out.println("After enqueue: " + genericQueue);

        System.out.println("\nDequeuing elements:");
        Integer dequeuedItem = genericQueue.dequeue();
        System.out.println("Dequeued: " + dequeuedItem);
        System.out.println("After dequeue: " + genericQueue);
    }
}

